package com.example.mobdeve

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mobdeve.databinding.MainMenuBinding
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Locale

class MainTodoActivity : AppCompatActivity() {
    private lateinit var viewBinding: MainMenuBinding
    private var userId: Long = -1;
    private lateinit var username: String; // username of user passed from login in case need idisplay
    private lateinit var listTodo: ArrayList<TodoModel>
    private lateinit var dbHelper: DBHelper

    private fun todoArrayTimeConvert(listTodo: ArrayList<TodoModel>) : Unit{
        for (todo in listTodo){
            val oldDueDate = todo.dueDate;
            val oldAlarmDate = todo.AlarmDate;

            // Define the formatters
            val originalFormatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
            val newTimeFormatter = SimpleDateFormat("hh:mm a", Locale.getDefault()) // Format for AM/PM

            // Parse the original string into Date
            val dateDue = originalFormatter.parse(oldDueDate)
            val dateAlarm = originalFormatter.parse(oldAlarmDate)

            // Extract the date part and format the time
            val dueDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(dateDue) // Keep the date part
            val dueTime = newTimeFormatter.format(dateDue) // Format the time
            val alarmDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(dateAlarm) // Keep the date part
            val alarmTime = newTimeFormatter.format(dateAlarm) // Format the time

            // Combine them back into the desired format
            val newDueDate = "$dueDate $dueTime"
            val newAlarmDate = "$alarmDate $alarmTime"
            todo.dueDate = newDueDate
            todo.AlarmDate = newAlarmDate
        }
    }

    private fun todoSpecificTimeConvert(todo: TodoModel){
        val oldDueDate = todo.dueDate;
        val oldAlarmDate = todo.AlarmDate;

        // Define the formatters
        val originalFormatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
        val newTimeFormatter = SimpleDateFormat("hh:mm a", Locale.getDefault()) // Format for AM/PM

        // Parse the original string into Date
        val dateDue = originalFormatter.parse(oldDueDate)
        val dateAlarm = originalFormatter.parse(oldAlarmDate)

        // Extract the date part and format the time
        val dueDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(dateDue) // Keep the date part
        val dueTime = newTimeFormatter.format(dateDue) // Format the time
        val alarmDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(dateAlarm) // Keep the date part
        val alarmTime = newTimeFormatter.format(dateAlarm) // Format the time

        // Combine them back into the desired format
        val newDueDate = "$dueDate $dueTime"
        val newAlarmDate = "$alarmDate $alarmTime"
        todo.dueDate = newDueDate
        todo.AlarmDate = newAlarmDate
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        userId = getUserId()
        // Used to make a predefined data
        //val demoTodo: TodoModel = TodoModel("SQL Tables Report", "Major", "make report on given SQL Tables", "CCINFOM", "Medium", "5/5/2025 9:00PM", "4/4/2025 5:00PM", true)
        //val demoTodo2: TodoModel = TodoModel("Create Prompts", "Major", "make prompts based on given description (5 Sentences)", "ITPLANN", "Hard", "5/5/2025 9:00PM", "4/4/2025 5:00PM", true)
        //val demoTodo3: TodoModel = TodoModel("Find Nemo", "GE", "Using FindNemo.com, find nemo based on parameters", "CCINTSY", "Easy", "5/5/2025 9:00PM", "4/4/2025 5:00PM", true)
        //val demoTodo4: TodoModel = TodoModel("Be Faithful", "LC", "Write a paragraph regarding your experience in Praying", "LCENWRD", "Medium", "5/5/2025 9:00PM", "4/4/2025 5:00PM", true)
        dbHelper = DBHelper(this, null)
        listTodo = ArrayList(dbHelper.getTodo(userId = userId))
        todoArrayTimeConvert(listTodo)


        super.onCreate(savedInstanceState)
        enableEdgeToEdge()



        viewBinding = MainMenuBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)




        val myActivityLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            if (result.resultCode == RESULT_OK) {
                val intent = result.data
                val option: String = intent?.getStringExtra("inputOptions").toString()


                when (option){
                    "add" -> {
                        val title: String = intent?.getStringExtra("inputTitle").toString()
                        Log.d("LOG", "title: " + title)
                        val addedTodo: TodoModel? = dbHelper.getSpecificTodo(title, userId)
                        Log.d("LOG", "THIS IS IT"  + addedTodo)
                        if (addedTodo != null) {
                            todoSpecificTimeConvert(addedTodo)
                            listTodo.add(addedTodo)
                            viewBinding.rvRecycler.adapter?.notifyItemInserted(listTodo.size - 1)
                        }else{
                            Log.d("LOG","failed viewing just added todo - failed view")
                        }
                    }
                    "update" -> {
                        val title: String = intent?.getStringExtra("inputTitle").toString()
                        val position: Int? = intent?.getIntExtra("inputPosition", -1)
                        Log.d("LOGP", position.toString())
                        if (position != null) {
                            val updatedTodo = dbHelper.getSpecificTodo(title, userId)!!
                            todoSpecificTimeConvert(updatedTodo)
                            listTodo[position] =  updatedTodo
                            viewBinding.rvRecycler.adapter?.notifyItemChanged(position)
                        }

                    }
                }


            } else if (result.resultCode == RESULT_CANCELED) {

            }
        }

        viewBinding.rvRecycler.adapter = MyAdapter(listTodo, myActivityLauncher)
        viewBinding.rvRecycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)


        username = intent.getStringExtra("user_username").toString()


        // DROPDOWN
        val dropdown: Spinner = viewBinding.imgvOptions
        val items: ArrayList<String> = arrayListOf("Subject Type", "Difficulty", "Date", "unfinished")
        val dropdownadapter: ArrayAdapter<String> = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        dropdown.adapter = dropdownadapter
        //https://www.youtube.com/watch?v=4ogzfAipGS8

        // helpers for sorting
        val sortedValues = mapOf("Easy" to 1, "Medium" to 2  ,"Hard" to 3 )
        val dateFormat = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.getDefault())

        dropdown.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {

                if (items[position] == "Subject Type") {
                    listTodo.sortBy {it.type}
                }
                if (items[position] == "Difficulty") {
                    listTodo.sortBy {sortedValues[it.difficulty]}
                }
                if (items[position] == "Date") {
                    listTodo.sortBy { dateFormat.parse(it.dueDate) }
                }
                if (items[position] == "Unfinished") {
                    listTodo.sortBy {it.isFinished}
                }
                viewBinding.rvRecycler.adapter?.notifyDataSetChanged()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {

            }
        }

        // This is used to create like seperation between the rows of recycler view
        viewBinding.rvRecycler.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
                outRect.bottom = 50
            }
        })


        viewBinding.imgvAdd.setOnClickListener(){
            val intent = Intent(this, AddTodoActivity::class.java)
            myActivityLauncher.launch(intent)

        }




    }
    private fun getUserId(): Long {
        val sharedPreferences = getSharedPreferences("mainPreference", Context.MODE_PRIVATE)
        val userId = sharedPreferences.getLong("USER_ID", -1)
        return userId
    }
}