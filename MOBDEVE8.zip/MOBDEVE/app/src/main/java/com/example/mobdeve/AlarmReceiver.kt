package com.example.mobdeve

class AlarmReceiver {
}