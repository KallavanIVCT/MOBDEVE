package com.example.mobdeve

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DBHelper(context: Context, factory: SQLiteDatabase.CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {

    companion object{
        // below is variable for database name
        private val DATABASE_NAME = "MOBDEVE"

        // below is the variable for database version
        private val DATABASE_VERSION = 1

        val TABLE_USER = "user"
        val USERNAME_COL = "username"
        val PASSWORD_COL = "password"

        val TABLE_TODO = "todo"
        val TITLE_COL = "title"
        val SUBJECT_COL = "subject"
        val SUBJECT_TYPE_COL = "subject_type"
        val DESCRIPTION_COL = "description"
        val DIFFICULTY_COL = "difficulty"
        val ALARM_DATE_COL = "alarm_date"
        val DUE_DATE_COL = "due_date"
        val IS_DONE_COL = "is_done"
    }

    // below is the method for creating a database by a sqlite query
    override fun onCreate(db: SQLiteDatabase) {
        // below is a sqlite query, where column names
        // along with their data types is given
        val tableCreateUser = (
                "CREATE TABLE " + TABLE_USER + " ("
                + "id" + " INTEGER PRIMARY KEY, " +
                USERNAME_COL + " TEXT," +
                PASSWORD_COL + " TEXT" + ")"
                )
        val tableCreateTodo = """
                CREATE TABLE $TABLE_TODO (
                id INTEGER PRIMARY KEY,
                $TITLE_COL TEXT,
                $SUBJECT_COL TEXT,
                $SUBJECT_TYPE_COL TEXT,
                $DESCRIPTION_COL TEXT,
                $DIFFICULTY_COL TEXT,
                $ALARM_DATE_COL TEXT,
                $IS_DONE_COL INTEGER,
                $DUE_DATE_COL TEXT,
                CONSTRAINT name_unique UNIQUE ($TITLE_COL)
                )""".trimIndent()
        db.execSQL(tableCreateUser)
        db.execSQL(tableCreateTodo)
    }

    override fun onUpgrade(db: SQLiteDatabase, p1: Int, p2: Int) {
        // this method is to check if table already exists
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TODO)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER)
        onCreate(db)
    }
    // This method is for adding data in our database
    fun createTodo(title: String, subject : String, subjectType: String, description: String,  difficulty: String, alarmDate: String, dueDate: String, isDone: Int) : Boolean{

        // below we are creating
        // a content values variable
        val values = ContentValues()

        // we are inserting our values
        // in the form of key-value pair
        values.put(TITLE_COL, title)
        values.put(SUBJECT_COL, subject)
        values.put(SUBJECT_TYPE_COL, subjectType)
        values.put(DESCRIPTION_COL, description)
        values.put(DIFFICULTY_COL, difficulty)
        values.put(ALARM_DATE_COL, alarmDate)
        values.put(DUE_DATE_COL, dueDate)
        values.put(IS_DONE_COL, isDone)
        var result: Long = -1  // default false
        val db = this.writableDatabase
        try{
            result = db.insert(TABLE_TODO, null, values)
        }catch(e: Exception){
            Log.d("LOG", e.message.toString())
        }finally{
            db.close()
        }
        return result != -1L // Returns true if insert was successful, false otherwise




    }
    fun getTodo(sort: String = "Date"): ArrayList<TodoModel>{
        val todoList = mutableListOf<TodoModel>()
        val db = this.readableDatabase
        val cursor: Cursor

        if (sort == "Date"){
            cursor = db.rawQuery("SELECT * FROM $TABLE_TODO ORDER BY $DUE_DATE_COL ASC", null)
            while (cursor.moveToNext()){
                val title = cursor.getString(cursor.getColumnIndexOrThrow(TITLE_COL))
                val type = cursor.getString(cursor.getColumnIndexOrThrow(SUBJECT_TYPE_COL))
                val description = cursor.getString(cursor.getColumnIndexOrThrow(DESCRIPTION_COL))
                val subject = cursor.getString(cursor.getColumnIndexOrThrow(SUBJECT_COL))
                val difficulty = cursor.getString(cursor.getColumnIndexOrThrow(DIFFICULTY_COL))
                val alarmDate = cursor.getString(cursor.getColumnIndexOrThrow(ALARM_DATE_COL))
                val dueDate = cursor.getString(cursor.getColumnIndexOrThrow(DUE_DATE_COL))
                val isDone = cursor.getInt(cursor.getColumnIndexOrThrow(IS_DONE_COL))
                val todo = TodoModel(title, type, description, subject, difficulty, dueDate, alarmDate, isDone == 1)
                todoList.add(todo)

            }
            cursor.close()
        }else if (sort == "Subject Type"){
            cursor = db.rawQuery("SELECT * FROM $TABLE_TODO ORDER BY $SUBJECT_COL ASC", null)
            while (cursor.moveToNext()){
                val title = cursor.getString(cursor.getColumnIndexOrThrow(TITLE_COL))
                val type = cursor.getString(cursor.getColumnIndexOrThrow(SUBJECT_TYPE_COL))
                val description = cursor.getString(cursor.getColumnIndexOrThrow(DESCRIPTION_COL))
                val subject = cursor.getString(cursor.getColumnIndexOrThrow(SUBJECT_COL))
                val difficulty = cursor.getString(cursor.getColumnIndexOrThrow(DIFFICULTY_COL))
                val alarmDate = cursor.getString(cursor.getColumnIndexOrThrow(ALARM_DATE_COL))
                val dueDate = cursor.getString(cursor.getColumnIndexOrThrow(DUE_DATE_COL))
                val isDone = cursor.getInt(cursor.getColumnIndexOrThrow(IS_DONE_COL))
                val todo = TodoModel(title, type, description, subject, difficulty, dueDate, alarmDate, isDone == 1)
                todoList.add(todo)

            }
            cursor.close()
        }else if (sort == "Difficulty"){
            cursor = db.rawQuery("SELECT * FROM $TABLE_TODO ORDER BY $DIFFICULTY_COL ASC", null)
            while (cursor.moveToNext()){
                val title = cursor.getString(cursor.getColumnIndexOrThrow(TITLE_COL))
                val type = cursor.getString(cursor.getColumnIndexOrThrow(SUBJECT_TYPE_COL))
                val description = cursor.getString(cursor.getColumnIndexOrThrow(DESCRIPTION_COL))
                val subject = cursor.getString(cursor.getColumnIndexOrThrow(SUBJECT_COL))
                val difficulty = cursor.getString(cursor.getColumnIndexOrThrow(DIFFICULTY_COL))
                val alarmDate = cursor.getString(cursor.getColumnIndexOrThrow(ALARM_DATE_COL))
                val dueDate = cursor.getString(cursor.getColumnIndexOrThrow(DUE_DATE_COL))
                val isDone = cursor.getInt(cursor.getColumnIndexOrThrow(IS_DONE_COL))
                val todo = TodoModel(title, type, description, subject, difficulty, dueDate, alarmDate, isDone == 1)
                todoList.add(todo)

            }
            cursor.close()
        }else{
            cursor = db.rawQuery("SELECT * FROM $TABLE_TODO", null)
            while (cursor.moveToNext()){
                val title = cursor.getString(cursor.getColumnIndexOrThrow(TITLE_COL))
                val type = cursor.getString(cursor.getColumnIndexOrThrow(SUBJECT_TYPE_COL))
                val description = cursor.getString(cursor.getColumnIndexOrThrow(DESCRIPTION_COL))
                val subject = cursor.getString(cursor.getColumnIndexOrThrow(SUBJECT_COL))
                val difficulty = cursor.getString(cursor.getColumnIndexOrThrow(DIFFICULTY_COL))
                val alarmDate = cursor.getString(cursor.getColumnIndexOrThrow(ALARM_DATE_COL))
                val dueDate = cursor.getString(cursor.getColumnIndexOrThrow(DUE_DATE_COL))
                val isDone = cursor.getInt(cursor.getColumnIndexOrThrow(IS_DONE_COL))
                val todo = TodoModel(title, type, description, subject, difficulty, dueDate, alarmDate, isDone == 1)
                todoList.add(todo)

            }
            cursor.close()
        }
        return ArrayList(todoList)
    }

    fun getSpecificTodo(title: String) : TodoModel? {
        val db = this.readableDatabase
        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_TODO WHERE $TITLE_COL = ?", arrayOf(title))
        var specificTodo: TodoModel? = null
        while (cursor.moveToNext()){
            val title = cursor.getString(cursor.getColumnIndexOrThrow(TITLE_COL))
            val type = cursor.getString(cursor.getColumnIndexOrThrow(SUBJECT_TYPE_COL))
            val description = cursor.getString(cursor.getColumnIndexOrThrow(DESCRIPTION_COL))
            val subject = cursor.getString(cursor.getColumnIndexOrThrow(SUBJECT_COL))
            val difficulty = cursor.getString(cursor.getColumnIndexOrThrow(DIFFICULTY_COL))
            val alarmDate = cursor.getString(cursor.getColumnIndexOrThrow(ALARM_DATE_COL))
            val dueDate = cursor.getString(cursor.getColumnIndexOrThrow(DUE_DATE_COL))
            val isDone = cursor.getInt(cursor.getColumnIndexOrThrow(IS_DONE_COL))
            specificTodo = TodoModel(title, type, description, subject, difficulty, dueDate, alarmDate, isDone == 1)
        }
        cursor.close()
        return specificTodo
    }

    fun updateTodo(originalTitle: String, title: String, subject : String, subjectType: String, description: String,  difficulty: String, alarmDate: String, dueDate: String, isDone: Int): Boolean {


        Log.d("HELP", "ORIG: " + originalTitle +" Title: " + title)
        // Calling a method to get writable database.
        val db = this.writableDatabase
        val values = ContentValues()

        // On below line we are passing all values along with its key and value pair.
        values.put(TITLE_COL, title)
        values.put(SUBJECT_COL, subject)
        values.put(SUBJECT_TYPE_COL, subjectType)
        values.put(DESCRIPTION_COL, description)
        values.put(DIFFICULTY_COL, difficulty)
        values.put(ALARM_DATE_COL, alarmDate)
        values.put(DUE_DATE_COL, dueDate)
        values.put(IS_DONE_COL, isDone)


         // result value is how much was updated
        var result = -1
        try{
            result = db.update(TABLE_TODO, values, "$TITLE_COL = ?", arrayOf(originalTitle))
        }catch(e: Exception){
            Log.d("LOG", e.message.toString())
        }finally{
            db.close()
        }
        val resultActual: Boolean = result > 0
        return  resultActual;

    }
    fun deleteTodo(title: String){
        // Calling a method to get writable database.
        val db = this.writableDatabase
        db.delete(TABLE_TODO,"name = ?", arrayOf(title))
        db.close()
    }


    // remember to do the encryption thingy sa database.
    // put more columns if needed.
    fun createUser(){

    }
    fun deleteUser(){

    }
    fun readUser(){

    }
    /* IDK if need
    fun updateUser(){

    }
     */

}