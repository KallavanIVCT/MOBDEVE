package com.example.mobdeve

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.mobdeve.databinding.SignupMenuBinding
import java.security.MessageDigest

class SignupActivity : AppCompatActivity() {
    private lateinit var viewBinding: SignupMenuBinding
    private lateinit var dbHelper: DBHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        viewBinding = SignupMenuBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)
        dbHelper = DBHelper(this,null)

        viewBinding.btnSignup.setOnClickListener(){
            val input_username : String = viewBinding.btnSignup.text.toString()
            val input_password : String = viewBinding.btnSignup.text.toString()
            signupValidation(input_username, input_password)
        }
    }

    fun hashPassword(password: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val hashedBytes = md.digest(password.toByteArray())
        return hashedBytes.joinToString("") { "%02x".format(it) }
    }

    private fun signupValidation(input_username: String, input_password: String){
        if (input_password.isEmpty() && input_username.isEmpty()){
            Toast.makeText(this, "Please enter a username and a password", Toast.LENGTH_SHORT).show()
        }
        else if (input_username.isEmpty()){
            Toast.makeText(this, "Please enter a proper username", Toast.LENGTH_SHORT).show()
        }
        else if (input_password.isEmpty()){
            Toast.makeText(this, "Please enter a proper password", Toast.LENGTH_SHORT).show()
        }else{
            val hashedPassword = hashPassword(input_password) // Encrypt the password

            // Check if username already exists
            if (dbHelper.checkUsername(input_username)) {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show()
            } else {
                // Insert user with hashed password
                val result = dbHelper.signupUser(input_username, hashedPassword)
                if (result != -1L) {
                    // Go to login activity if signup is successful
                    val intent = Intent(this, LoginActivity::class.java)
                    intent.putExtra("user_username", input_username)
                    startActivity(intent)
                    Toast.makeText(this, "Sign up successful!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Sign up failed. Please try again.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }



}