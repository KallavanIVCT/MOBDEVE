package com.example.mobdeve

import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mobdeve.databinding.AddTodoMenuBinding
import com.example.mobdeve.databinding.MainMenuBinding

class MainTodoActivity : AppCompatActivity() {
    private lateinit var viewBinding: MainMenuBinding
    private lateinit var username: String; // username of user passed from login in case need idisplay
    private lateinit var listTodo: ArrayList<TodoModel>
    private lateinit var dbHelper: DBHelper
    override fun onCreate(savedInstanceState: Bundle?) {

        // Used to make a predefined data
        val demoTodo: TodoModel = TodoModel("SQL Tables Report", "Major", "make report on given SQL Tables", "CCINFOM", "Medium", "5/5/2025 9:00PM", "4/4/2025 5:00PM", true)
        val demoTodo2: TodoModel = TodoModel("Create Prompts", "Major", "make prompts based on given description (5 Sentences)", "ITPLANN", "Hard", "5/5/2025 9:00PM", "4/4/2025 5:00PM", true)
        val demoTodo3: TodoModel = TodoModel("Find Nemo", "GE", "Using FindNemo.com, find nemo based on parameters", "CCINTSY", "Easy", "5/5/2025 9:00PM", "4/4/2025 5:00PM", true)
        val demoTodo4: TodoModel = TodoModel("Be Faithful", "LC", "Write a paragraph regarding your experience in Praying", "LCENWRD", "Medium", "5/5/2025 9:00PM", "4/4/2025 5:00PM", true)
        //dbHelper = DBHelper(this, null) for mco3
        //listTodo = ArrayList(dbHelper.getTodo()) for mco3
        listTodo =ArrayList<TodoModel>()
        listTodo.add(demoTodo)
        listTodo.add(demoTodo2)
        listTodo.add(demoTodo3)
        listTodo.add(demoTodo4)


        super.onCreate(savedInstanceState)
        enableEdgeToEdge()



        viewBinding = MainMenuBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        // SPINNER
        val dropdown: Spinner = viewBinding.imgvOptions
        val items: ArrayList<String> = arrayListOf("Subject Type", "Difficulty", "Date", "unfinished")
        val dropdownadapter: ArrayAdapter<String> = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        dropdown.adapter = dropdownadapter


        val myActivityLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            if (result.resultCode == RESULT_OK) {
                val intent = result.data
                val option: String = intent?.getStringExtra("inputOptions").toString()


                when (option){
                    "add" -> {
                        val title: String = intent?.getStringExtra("inputTitle").toString()
                        Log.d("LOG", "title: " + title)
                        val addedTodo: TodoModel? = dbHelper.getSpecificTodo(title)
                        Log.d("LOG", "THIS IS IT"  + addedTodo)
                        if (addedTodo != null) {
                            listTodo.add(addedTodo)
                            viewBinding.rvRecycler.adapter?.notifyItemInserted(listTodo.size - 1)
                        }else{
                            Log.d("LOG","failed viewing just added todo - failed view")
                        }
                    }
                    "update" -> {
                        val title: String = intent?.getStringExtra("inputTitle").toString()
                        val position: Int? = intent?.getIntExtra("inputPosition", -1)
                        Log.d("LOGP", position.toString())
                        if (position != null) {
                            listTodo[position] = dbHelper.getSpecificTodo(title)!!
                            viewBinding.rvRecycler.adapter?.notifyItemChanged(position)
                        }

                    }
                }


            } else if (result.resultCode == RESULT_CANCELED) {

            }
        }


        viewBinding.rvRecycler.adapter = MyAdapter(listTodo, myActivityLauncher)
        viewBinding.rvRecycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        username = intent.getStringExtra("user_username").toString()




        // This is used to create like seperation between the rows of recycler view
        viewBinding.rvRecycler.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
                outRect.bottom = 50
            }
        })


        viewBinding.imgvAdd.setOnClickListener(){
            val intent = Intent(this, AddTodoActivity::class.java)
            myActivityLauncher.launch(intent)

        }



    }
}