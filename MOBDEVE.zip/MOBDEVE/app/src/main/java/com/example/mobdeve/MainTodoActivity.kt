package com.example.mobdeve

import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mobdeve.databinding.AddTodoMenuBinding
import com.example.mobdeve.databinding.MainMenuBinding

class MainTodoActivity : AppCompatActivity() {
    private lateinit var viewBinding: MainMenuBinding
    private lateinit var username: String; // username of user passed from login in case need idisplay
    private lateinit var listTodo: ArrayList<TodoModel>
    override fun onCreate(savedInstanceState: Bundle?) {

        // Used to make a predefined data
        val demoTodo: TodoModel = TodoModel("Finish Exam", "GE", "study network", "GEWORLD", "HARD", "2024", "2025", true)
        val demoTodo2: TodoModel = TodoModel("Finish Exam", "GE", "study network", "GEWORLD", "HARD", "2024", "2025", true)
        listTodo = ArrayList()
        listTodo.add(demoTodo2)
        listTodo.add(demoTodo)



        super.onCreate(savedInstanceState)
        enableEdgeToEdge()



        viewBinding = MainMenuBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)


        val myActivityLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
            if (result.resultCode == RESULT_OK) {
                if (true) { //desc != null
                    //this.listTodo.add(TodoModel("Finish Exam", "GE", "study network", "GEWORLD", "HARD", "2024", "2025", true))
                    //viewBinding.rvRecycler.adapter?.notifyItemInserted(0)
                }
            } else if (result.resultCode == RESULT_CANCELED) {

            }
        }

        viewBinding.rvRecycler.adapter = MyAdapter(listTodo, myActivityLauncher)
        viewBinding.rvRecycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        username = intent.getStringExtra("user_username").toString()



        // This is used to create like seperation between the rows of recycler view
        viewBinding.rvRecycler.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
                outRect.bottom = 50
            }
        })


        viewBinding.imgvAdd.setOnClickListener(){
            val intent = Intent(this, AddTodoActivity::class.java)
            myActivityLauncher.launch(intent)

        }



    }
}