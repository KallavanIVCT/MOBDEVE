package com.example.mobdeve

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.mobdeve.databinding.EditTodoMenuBinding

class EditTodoActivity : AppCompatActivity() {
    private lateinit var viewBinding: EditTodoMenuBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        viewBinding = EditTodoMenuBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)


    }
}