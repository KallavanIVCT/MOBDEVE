package com.example.mobdeve

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.mobdeve.databinding.AddTodoMenuBinding

// OnDatePass interface para interact with fragment to activity
class AddTodoActivity : AppCompatActivity(), OnDatePass, OnTimePass {
    private lateinit var dueDate: String;
    private lateinit var dueTime: String;
    private lateinit var alarmTime: String;
    private lateinit var alarmDate: String;
    private lateinit var viewBinding: AddTodoMenuBinding;

    // to Seperate ung duetime and alarmtime since same sila nang ginagamit na class
    private var isDueTime: Boolean = false
    private var isDueDate: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewBinding = AddTodoMenuBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        viewBinding.btnAddDueTime.setOnClickListener(){
            isDueTime = true
            val timePicker: TimePickerFragment = TimePickerFragment()
            timePicker.show(supportFragmentManager, "timepicker")
        }
        viewBinding.btnAddDueDate.setOnClickListener(){
            isDueDate = true
            val datePicker: DatePickerFragment = DatePickerFragment()
            datePicker.show(supportFragmentManager, "datepicker")
        }
        viewBinding.btnAddAlarmTime.setOnClickListener(){
            val timePicker: TimePickerFragment = TimePickerFragment()
            timePicker.show(supportFragmentManager, "timepicker")
        }
        viewBinding.btnAddAlarmDate.setOnClickListener(){
            val datePicker: DatePickerFragment = DatePickerFragment()
            datePicker.show(supportFragmentManager, "datepicker")
        }

        viewBinding.btnAddTodo.setOnClickListener(){
            setResult(RESULT_OK, intent)
            finish()
        }

    }

    override fun onTimePass(data: String) {
        if(isDueTime){
            Log.d("LOG", "DueTime: " + data)
            dueTime = data
            viewBinding.btnAddDueTime.text = dueTime
            isDueTime = false
        }else{
            Log.d("LOG", "AlarmTime: " + data)
            alarmTime = data
            viewBinding.btnAddAlarmTime.text = alarmTime
        }

    }
    override fun onDatePass(data: String) {
        if(isDueDate){
            Log.d("LOG", "DueDate: " + data)
            dueDate = data
            viewBinding.btnAddDueDate.text = dueDate
            isDueDate = false
        }else{
            Log.d("LOG", "AlarmDate: " + data)
            alarmDate = data
            viewBinding.btnAddAlarmDate.text = alarmDate
        }
    }
    fun validateAddUserInput(){
        var title : String = viewBinding.etAddTitle.text.toString()
        var type: String = viewBinding.etAddSubject.text.toString()
        var description: String= viewBinding.etAddDescription.text.toString()
        var subject: String = "Placeholder"
        var difficulty: String = "Placeholder"

        if(viewBinding.rbAddGE.isChecked){
            subject = viewBinding.rbAddGE.text.toString()
        }
        if(viewBinding.rbAddLC.isChecked){
            subject = viewBinding.rbAddLC.text.toString()
        }
        if(viewBinding.rbAddMajor.isChecked){
            subject = viewBinding.rbAddMajor.text.toString()
        }
        if(viewBinding.rbAddEasy.isChecked){
            difficulty = viewBinding.rbAddEasy.text.toString()
        }
        if(viewBinding.rbAddMedium.isChecked){
            difficulty = viewBinding.rbAddMedium.text.toString()
        }
        if(viewBinding.rbAddHard.isChecked){
            difficulty = viewBinding.rbAddHard.text.toString()
        }


        var dueCombinedDate: String =  dueTime + dueDate;
        var alarmCombinedDate: String = alarmTime + alarmDate

        // fix this next time add duetimedate and alarmtimedate
        if(title.isNotEmpty() && type.isNotEmpty() && description.isNotEmpty() && subject.isNotEmpty() && difficulty.isNotEmpty() && dueCombinedDate.isNotEmpty() && alarmCombinedDate.isNotEmpty()){
            // Put database commands here

            setResult(Activity.RESULT_OK, intent)


            finish()
        }

    }


}

