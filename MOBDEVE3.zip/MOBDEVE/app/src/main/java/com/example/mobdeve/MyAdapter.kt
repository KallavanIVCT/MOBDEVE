package com.example.mobdeve

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.recyclerview.widget.RecyclerView.Adapter
import com.example.mobdeve.databinding.TodoLayoutBinding

class MyAdapter(private val data: ArrayList<TodoModel>, private val myActivityResultLauncher: ActivityResultLauncher<Intent>): Adapter<MyViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemViewBinding: TodoLayoutBinding = TodoLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false )
        return MyViewHolder(itemViewBinding)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bindData(data[position])
        holder.itemView.setOnClickListener(){
            val intent = Intent(holder.itemView.context,  EditTodoActivity::class.java) // this should be in UpdateTodoActivity
            myActivityResultLauncher.launch(intent)
        }
    }
}